﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UploadController : ControllerBase
    {

        //метод возвращает топ часто встреяающихся слов и их количество
        public Dictionary<string, int> GetTopWords(int count)
        {

            string path = _environment.WebRootPath + "\\Files\\" +"hello.txt";
            Dictionary<string, int> dict = new Dictionary<string, int>();

            //считываем данные файла
            using (StreamReader sr = new StreamReader(path))
            {
                //разделяем текст на слова
                //переводим все слова в нижний решистр
                //считаем количество повторений
                
                var words = from word in sr.ReadToEnd().Split(new[] { '.', '?', '!', ' ' })

                            group word by word.ToLower() into g
                            select new { Word = g.Key, Count = g.Count() } into g1
                            orderby g1.Count descending
                            select g1;
                var topWords = words.Take(count);
                //в словаь записаываем слова и количество повторений
                foreach (var item in topWords)
                {

                    dict.Add(item.Word, item.Count);


                }
            }


                             
            return dict;
        }
        [HttpGet]
        public string Get()
        {

            return "REST API";
        }
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]

        // GET: api/Default
        [HttpGet("{count}", Name = "Get")]
        public IActionResult Get( int count)
        {


            Dictionary<string, int> dict = GetTopWords( count);

           
            return Ok(dict);
        }



        public static IWebHostEnvironment _environment;
        public UploadController(IWebHostEnvironment environment)
        {
            _environment = environment;
        }
        public class FileUPloadAPI
        {
            public IFormFile files { get; set; }
        }


       


        //отправка файла на сервер
        [HttpPost]
        public async Task<string> Post([FromForm] FileUPloadAPI objFile)
        {
            try
            {
                if (objFile.files.Length > 0)
                {
                  if (!Directory.Exists(_environment.WebRootPath + "\\Files\\"))
                    {
                        Directory.CreateDirectory(_environment.WebRootPath + "\\Files\\");

                    }
                    using (FileStream fileStream = System.IO.File.Create(_environment.WebRootPath + "\\Files\\" + objFile.files.FileName))
                    {
                        objFile.files.CopyTo(fileStream);
                        fileStream.Flush();
                        return "\\Files\\" + objFile.files.FileName;

                    }
                }
                else
                {
                    return "Failled";
                }
            }
            catch (Exception ex)
            {

                return ex.Message.ToString();
            }

        }
    }
}