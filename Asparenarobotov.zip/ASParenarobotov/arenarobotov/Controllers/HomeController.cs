﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ArenaRobotov.Models;
using ArenaRobotov;

namespace Arenarobotov.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }


        public async Task<IActionResult> Request(Customer customer)
        {
            EmailService emailService = new EmailService();

            await emailService.SendEmailAsync("smbatyan97@ya.ru", customer);
            return RedirectToAction("Index");
        }
    }
}
