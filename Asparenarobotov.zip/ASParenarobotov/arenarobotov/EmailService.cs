﻿using System;
using System.Collections.Generic;
using System.Linq;
using MimeKit;
using MailKit.Net.Smtp;
using System.Threading.Tasks;
using ArenaRobotov.Models;
namespace ArenaRobotov
{
    public class EmailService
    {
        public async Task SendEmailAsync(string email,  Customer customer)
        {
            var emailMessage = new MimeMessage();

            emailMessage.From.Add(new MailboxAddress("Администрация сайта", "exampleaspnetcore@gmail.com"));
            emailMessage.To.Add(new MailboxAddress(email));
            emailMessage.Subject = "Новая заявка";
            emailMessage.Body = new TextPart("Plain")
            {
                Text = $"Имя: {customer.Name} \nПочта: {customer.Email}"
            };
            

            using (var client = new SmtpClient())
            {
                await client.ConnectAsync("smtp.gmail.com", 465, true);
                await client.AuthenticateAsync("exampleaspnetcore@gmail.com", "primer123*");
                await client.SendAsync(emailMessage);

                await client.DisconnectAsync(true);
            }
        }
    }
}
