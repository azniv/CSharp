﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Authorization.Models;
using Microsoft.EntityFrameworkCore;

namespace Authorization.Controllers
{
    public class HomeController : Controller
    {

       
        ApplicationContext db;
        public HomeController(ApplicationContext context)
        {
            db = context;
        }
        
        public IActionResult Info()
        {
            return View();
        }
        

        public IActionResult Registration()
        {
            return View();
        }


        public async Task<IActionResult> Index()
        {
            return View(await db.Users.ToListAsync());
        }
     
        [HttpPost]
        public async Task<IActionResult> Registration(User user)
        {
            db.Users.Add(user);
            await db.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        public async Task<IActionResult> Details(int? id)
        {
            if (id != null)
            {
                User user = await db.Users.FirstOrDefaultAsync(p => p.Id == id);
                if (user != null)
                    return View(user);
            }
            return NotFound();
        }


    }
}
