﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Authorization.Models;

namespace Authorization
{
    public class InitialData
    {
        public static void Initialize(ApplicationContext context)
        {
            if (!context.Users.Any())
            {
                context.Users.AddRange(
                    new User
                    {
                        Name = "John",
                        Surname = "Smith",
                        Login = "johnSmith@ml.ru",
                        Password = "Qwerty123",
                        Email = "johnSmith@ml.ru"



                    },
                    new User
                    {
                        Name = "Vanya",
                        Surname = "Ivanov",
                        Login = "Vanya123@ml.ru",
                        Password = "F345Hj23K",
                        Email = "Vanya123@ml.ru"
                    },
                    new User
                    {
                        Name = "John",
                        Surname = "Smith",
                        Login = "Liza6788@ml.ru",
                        Password = "Liza6788 ",
                        Email = "Liza6788@ml.ru"
                    }
                );

                context.SaveChanges();
            }
            if (!context.Admins.Any())
            {
                context.Admins.AddRange(
                    new Admin
                    {
                        Login = "Admin",
                        Phone = "81234567890",
                        Password = "admin"


                    },
                    new Admin
                    {
                        Login = "Master",
                        Phone = "81234567890",
                        Password = "Jnk2j2"


                    }
                );
                context.SaveChanges();
            }

        }
    }
}
